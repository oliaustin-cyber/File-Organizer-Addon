# file-organizer

A command-line tool that organizes a messy folder by file type - recursively,
with duplicate detection, date-based sorting, a dry-run preview, and a full
undo. One command, one terminal, and it works the same way on **Windows,
macOS, and Linux**.

```
$ file-organizer organize ~/Downloads --recursive --dedupe
Organized:
  Documents: 12 file(s)
  Images: 47 file(s)
  PDFs: 8 file(s)
  Archives: 3 file(s)
  Duplicates: 5 file(s)

Undo anytime with: file-organizer undo
```

## Features

- **Cross-platform** - pure Python stdlib, no OS-specific dependencies for
  the core tool.
- **Recursive, in place** - `--recursive` organizes every subfolder's own
  files where they are, preserving your folder structure, instead of
  dumping everything into one place.
- **Flatten mode** - `--flatten` pulls files from an entire folder tree up
  into category folders at the top, if that's what you actually want.
- **Duplicate detection** - `--dedupe` hashes file *contents* (not just
  names) and routes exact duplicates into a `Duplicates` folder.
- **Date sorting** - `--by-date` further sorts each category into
  `Year/Month` subfolders, great for photo dumps.
- **Dry-run preview** - `--dry-run` shows exactly what would move, without
  touching anything.
- **Full undo** - every real run writes a manifest; `file-organizer undo`
  puts every file back exactly where it came from, and cleans up any
  category folders it emptied out in the process.
- **Custom categories** - point `--config` at a small JSON file to add your
  own categories or override the defaults.
- **Ignore patterns** - skip files/folders with `--ignore '*.tmp'` (repeatable).
- **Safe by design** - never re-shuffles files already inside a category
  folder, never touches `.git`/`node_modules`/`venv`/etc., never overwrites
  a file (name collisions get an auto-incrementing suffix), and skips
  locked/in-use files instead of aborting the whole run.
- **Optional colored folder icons** - best-effort, off by default. Full
  support on Windows; on macOS/Linux it uses whatever tools you already
  have (see [Icons](#custom-folder-icons) below).

## Install

```bash
pip install file-organizer-cli
```

Or from source:

```bash
git clone https://github.com/YOUR_USERNAME/file-organizer.git
cd file-organizer
pip install -e .
```

Requires Python 3.8+. No other dependencies.

## Usage

```bash
# Organize a folder (top level only)
file-organizer organize ~/Downloads

# Organize every subfolder too, in place
file-organizer organize ~/Downloads --recursive

# Pull everything from the whole tree into top-level category folders
file-organizer organize ~/Downloads --flatten

# Preview first - nothing moves
file-organizer organize ~/Downloads --recursive --dry-run

# Also catch duplicate files (by content, not filename)
file-organizer organize ~/Downloads --recursive --dedupe

# Sort each category into Year/Month subfolders too
file-organizer organize ~/Pictures --by-date

# Skip certain files
file-organizer organize ~/Downloads --ignore '*.tmp' --ignore '.DS_Store'

# Use your own categories on top of the defaults
file-organizer organize ~/Downloads --config my-categories.json

# Undo the most recent run
file-organizer undo

# Preview an undo first
file-organizer undo --dry-run
```

Run logs live in `~/.file-organizer/logs/` (one JSON file per run) so undo
always knows what to reverse, even across separate terminal sessions.

### Custom categories

```json
{
  "Screenshots": [".png", ".jpg"],
  "Books": [".epub", ".mobi", ".azw3"]
}
```
Save as `my-categories.json` and pass `--config my-categories.json`. Any
extension you assign here is automatically removed from whichever default
category used to claim it, so there's never any ambiguity about where a
file ends up.

### Default categories

`Documents`, `PDFs`, `Spreadsheets`, `Presentations`, `Images`, `Videos`,
`Audio`, `Archives`, `Code`, `Executables`, `Text`, `Fonts`, and `Other`
for anything unrecognized.

## Custom folder icons

Pass `--icons` to any `organize` command to tag the category folders it
creates with color-coded icons. This is genuinely best-effort and degrades
silently if the platform tooling isn't available:

| Platform | Requirement |
|---|---|
| Windows | None - works out of the box (uses `desktop.ini`, same mechanism every native Windows folder icon uses) |
| macOS | [`fileicon`](https://github.com/mklement0/fileicon) (`brew install fileicon`) |
| Linux | `gio` (ships with GLib/GNOME) + a file manager that honors it, e.g. GNOME Files |

## OS-specific integrations (optional)

The CLI above is the whole tool and works everywhere on its own. For a
native right-click experience, optional extras live in `integrations/`:

- **`integrations/windows/`** - a full Explorer add-on: right-click context
  menu ("Organize This Folder"), custom default icons for common file
  types, an installer/uninstaller, and a diagnostic tool. See its own
  README-equivalent notes inside the folder.
- **`integrations/linux/organize-here.sh`** - a Nautilus (GNOME Files)
  script for a right-click "Organize Here" action.
- **`integrations/macos/`** - instructions for building a Finder Quick
  Action with Automator.

These are optional add-ons on top of the CLI, not required to use it.

## How undo works

Every non-dry-run `organize` writes a manifest of every file it moved
(`~/.file-organizer/logs/run-<timestamp>.json`). `file-organizer undo`
reads the most recent one (or a specific one via `--log`) and moves each
file back to its original path, most-recent-move-first, then removes any
category folders left empty afterward. It does not undo an undo - if you
want that, keep the log file and re-run `organize` again.

## Development

```bash
pip install -e ".[dev]"
pytest -v
```

Tests run on Windows, macOS, and Linux in CI (see `.github/workflows/tests.yml`).

## Contributing

Issues and PRs welcome - especially for more integrations (Windows Terminal
context menu variants, KDE/Dolphin service menus, additional category
presets) or edge cases the categorizer should handle better.

## License

MIT - see [LICENSE](LICENSE).
