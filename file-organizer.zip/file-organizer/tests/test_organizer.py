"""Basic tests - run with: pytest"""
from pathlib import Path

from file_organizer.organizer import organize, undo, categorize
from file_organizer.config import DEFAULT_CATEGORIES, load_categories


def make_file(path: Path, content: str = "x"):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


def test_categorize_known_extension():
    assert categorize(".pdf", DEFAULT_CATEGORIES) == "PDFs"
    assert categorize(".PDF", DEFAULT_CATEGORIES) == "PDFs"


def test_categorize_unknown_extension_falls_back_to_other():
    assert categorize(".xyz123", DEFAULT_CATEGORIES) == "Other"


def test_basic_organize(tmp_path):
    make_file(tmp_path / "a.pdf", "1")
    make_file(tmp_path / "b.jpg", "2")

    summary = organize(tmp_path)

    assert (tmp_path / "PDFs" / "a.pdf").exists()
    assert (tmp_path / "Images" / "b.jpg").exists()
    assert summary.moved == {"PDFs": 1, "Images": 1}


def test_dry_run_moves_nothing(tmp_path):
    make_file(tmp_path / "a.pdf", "1")

    summary = organize(tmp_path, dry_run=True)

    assert (tmp_path / "a.pdf").exists()
    assert not (tmp_path / "PDFs").exists()
    assert summary.moved == {"PDFs": 1}


def test_recursive_organizes_each_folder_in_place(tmp_path):
    make_file(tmp_path / "top.pdf", "1")
    make_file(tmp_path / "sub" / "nested.jpg", "2")

    organize(tmp_path, recursive=True)

    assert (tmp_path / "PDFs" / "top.pdf").exists()
    assert (tmp_path / "sub" / "Images" / "nested.jpg").exists()


def test_flatten_pulls_everything_to_top(tmp_path):
    make_file(tmp_path / "sub" / "nested.jpg", "2")

    organize(tmp_path, flatten=True)

    assert (tmp_path / "Images" / "nested.jpg").exists()
    assert not (tmp_path / "sub" / "Images").exists()


def test_dedupe_moves_duplicate_content_to_duplicates_folder(tmp_path):
    make_file(tmp_path / "a.txt", "same content")
    make_file(tmp_path / "b.txt", "same content")

    summary = organize(tmp_path, dedupe=True)

    assert summary.duplicates == 1
    assert (tmp_path / "Text" / "a.txt").exists()
    assert (tmp_path / "Duplicates" / "b.txt").exists()


def test_name_collision_gets_numbered_suffix(tmp_path):
    make_file(tmp_path / "PDFs" / "a.pdf", "existing")
    make_file(tmp_path / "a.pdf", "new")

    organize(tmp_path)

    assert (tmp_path / "PDFs" / "a.pdf").read_text() == "existing"
    assert (tmp_path / "PDFs" / "a (1).pdf").read_text() == "new"


def test_undo_restores_original_locations(tmp_path):
    make_file(tmp_path / "a.pdf", "1")
    make_file(tmp_path / "b.jpg", "2")
    log_path = tmp_path / "run.json"

    organize(tmp_path, log_path=log_path)
    assert not (tmp_path / "a.pdf").exists()

    restored = undo(log_path)

    assert restored == 2
    assert (tmp_path / "a.pdf").exists()
    assert (tmp_path / "b.jpg").exists()
    assert not (tmp_path / "PDFs").exists()  # emptied category folder cleaned up


def test_ignore_pattern_skips_matching_files(tmp_path):
    make_file(tmp_path / "keep.pdf", "1")
    make_file(tmp_path / "skip.tmp", "2")

    organize(tmp_path, ignore_patterns=["*.tmp"])

    assert (tmp_path / "PDFs" / "keep.pdf").exists()
    assert (tmp_path / "skip.tmp").exists()  # left alone


def test_custom_category_config(tmp_path):
    make_file(tmp_path / "shot.png", "1")
    config_path = tmp_path / "categories.json"
    config_path.write_text('{"Screenshots": [".png"]}')

    categories = load_categories(config_path)
    organize(tmp_path, categories=categories)

    assert (tmp_path / "Screenshots" / "shot.png").exists()
    assert ".png" not in categories["Images"]  # no longer ambiguous with Images


def test_second_run_does_not_reshuffle_already_organized_files(tmp_path):
    make_file(tmp_path / "a.pdf", "1")
    organize(tmp_path)
    make_file(tmp_path / "b.pdf", "2")

    summary = organize(tmp_path)

    assert summary.moved == {"PDFs": 1}  # only the new file
    assert (tmp_path / "PDFs" / "a.pdf").exists()
    assert (tmp_path / "PDFs" / "b.pdf").exists()
