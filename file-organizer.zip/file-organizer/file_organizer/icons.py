"""Best-effort custom folder icons, per platform.

This is intentionally optional and silently degrades: every function
here returns False (or is skipped) if the platform tool it needs isn't
available, rather than raising. Organizing files always works even if
none of this does anything on your system.

  Windows: full support, no extra tools needed (uses desktop.ini, the
           same mechanism every native Windows folder icon uses).
  macOS:   requires the community 'fileicon' CLI (brew install fileicon).
  Linux:   requires 'gio' (ships with GLib/GNOME - present on most
           GTK-based desktops) and a file manager that honors
           metadata::custom-icon (GNOME Files/Nautilus does).
"""
from __future__ import annotations

import platform
import shutil
import subprocess
from pathlib import Path

_ASSETS = Path(__file__).parent / "assets" / "icons"

_ICON_FOR_CATEGORY = {
    "Documents": "folder_documents", "PDFs": "folder_pdf",
    "Spreadsheets": "folder_spreadsheets", "Presentations": "folder_presentations",
    "Images": "folder_images", "Videos": "folder_videos",
    "Audio": "folder_audio", "Archives": "folder_archives",
    "Code": "folder_code", "Executables": "folder_executables",
    "Text": "folder_text", "Fonts": "folder_fonts",
    "Other": "folder_other", "Duplicates": "folder_other",
}


def tag_category_folders(root: Path, category_names: set[str]) -> int:
    """Tag every existing category subfolder of `root` with its icon.
    Returns how many folders were successfully tagged."""
    system = platform.system()
    tagger = {"Windows": _tag_windows, "Darwin": _tag_macos, "Linux": _tag_linux}.get(system)
    if not tagger:
        return 0

    count = 0
    for cat in category_names:
        folder = root / cat
        if not folder.is_dir():
            continue
        icon_base = _ICON_FOR_CATEGORY.get(cat, "folder_other")
        try:
            if tagger(folder, icon_base):
                count += 1
        except Exception:
            continue
    return count


def _tag_windows(folder: Path, icon_base: str) -> bool:
    icon_src = _ASSETS / f"{icon_base}.ico"
    if not icon_src.exists():
        return False
    local_icon = folder / ".folder_icon.ico"
    shutil.copy(icon_src, local_icon)
    ini = folder / "desktop.ini"
    ini.write_text(
        f"[.ShellClassInfo]\nIconResource={local_icon},0\n[ViewState]\nMode=\nVid=\nFolderType=Generic\n",
        encoding="ascii",
    )
    subprocess.run(["attrib", "+h", "+s", str(ini)], check=False)
    subprocess.run(["attrib", "+h", str(local_icon)], check=False)
    subprocess.run(["attrib", "+s", str(folder)], check=False)
    return True


def _tag_macos(folder: Path, icon_base: str) -> bool:
    fileicon = shutil.which("fileicon")
    if not fileicon:
        return False
    icon_src = _ASSETS / f"{icon_base}.png"
    if not icon_src.exists():
        return False
    result = subprocess.run([fileicon, "set", str(folder), str(icon_src)], capture_output=True)
    return result.returncode == 0


def _tag_linux(folder: Path, icon_base: str) -> bool:
    gio = shutil.which("gio")
    if not gio:
        return False
    icon_src = _ASSETS / f"{icon_base}.png"
    if not icon_src.exists():
        return False
    result = subprocess.run(
        [gio, "set", str(folder), "metadata::custom-icon", f"file://{icon_src}"],
        capture_output=True,
    )
    return result.returncode == 0
