"""Core organizing logic - pure stdlib, fully cross-platform."""
from __future__ import annotations

import hashlib
import json
import shutil
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .config import DEFAULT_CATEGORIES, RESERVED_NAMES, DEFAULT_IGNORE_DIR_NAMES


@dataclass
class MoveRecord:
    src: str
    dst: str


@dataclass
class RunSummary:
    moved: dict[str, int] = field(default_factory=dict)
    duplicates: int = 0
    skipped: list[str] = field(default_factory=list)
    records: list[MoveRecord] = field(default_factory=list)
    log_path: Path | None = None


def categorize(extension: str, categories: dict[str, list[str]]) -> str:
    ext = extension.lower()
    for name, exts in categories.items():
        if ext in exts:
            return name
    return "Other"


def file_hash(path: Path, chunk_size: int = 1 << 16) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def _is_inside_reserved(path: Path, root: Path, all_category_names: set[str]) -> bool:
    """True if `path` sits inside a folder this tool created (or would
    create) for output, so we never re-shuffle our own sorted files."""
    try:
        parts = path.relative_to(root).parts[:-1]
    except ValueError:
        parts = path.parts[:-1]
    reserved = all_category_names | RESERVED_NAMES
    return any(part in reserved for part in parts)


def _should_ignore(path: Path, ignore_patterns: list[str]) -> bool:
    if any(part in DEFAULT_IGNORE_DIR_NAMES for part in path.parts):
        return True
    return any(path.match(pat) for pat in ignore_patterns)


def _unique_dest(dest: Path) -> Path:
    if not dest.exists():
        return dest
    base, ext, parent = dest.stem, dest.suffix, dest.parent
    i = 1
    while True:
        candidate = parent / f"{base} ({i}){ext}"
        if not candidate.exists():
            return candidate
        i += 1


def _move(src: Path, dst: Path, dry_run: bool) -> None:
    if dry_run:
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))


def _iter_folder_files(folder: Path, root: Path, category_names: set[str], ignore_patterns: list[str]):
    for p in sorted(folder.iterdir()):
        if p.is_file() and not _is_inside_reserved(p, root, category_names) \
                and not _should_ignore(p, ignore_patterns):
            yield p


def organize(
    root: Path,
    categories: dict[str, list[str]] | None = None,
    recursive: bool = False,
    flatten: bool = False,
    dry_run: bool = False,
    dedupe: bool = False,
    by_date: bool = False,
    ignore_patterns: list[str] | None = None,
    log_path: Path | None = None,
) -> RunSummary:
    """Organize `root`.

    - Default (recursive=False, flatten=False): sort files directly
      inside `root` only.
    - recursive=True: walk every subfolder and sort ITS OWN files in
      place (nested folder structure is preserved - a "Documents"
      folder appears inside each subfolder that has loose documents).
    - flatten=True: pull files from every subfolder up into category
      folders at the top of `root` (old "everything in one place"
      behavior). Takes precedence over recursive if both are set.
    """
    categories = categories or DEFAULT_CATEGORIES
    ignore_patterns = ignore_patterns or []
    category_names = set(categories)
    summary = RunSummary()
    seen_hashes: dict[str, Path] = {}

    if flatten:
        jobs: list[tuple[Path, Path]] = []  # (file, folder_it_organizes_into)
        for p in sorted(root.rglob("*")):
            if p.is_file() and not _is_inside_reserved(p, root, category_names) \
                    and not _should_ignore(p, ignore_patterns):
                jobs.append((p, root))
    elif recursive:
        jobs = []
        folders = [root] + sorted(d for d in root.rglob("*") if d.is_dir())
        for folder in folders:
            if folder.name in category_names or folder.name in RESERVED_NAMES:
                continue
            if any(part in DEFAULT_IGNORE_DIR_NAMES for part in folder.parts):
                continue
            for f in _iter_folder_files(folder, root, category_names, ignore_patterns):
                jobs.append((f, folder))
    else:
        jobs = [(f, root) for f in _iter_folder_files(root, root, category_names, ignore_patterns)]

    for f, dest_root in jobs:
        try:
            if dedupe:
                h = file_hash(f)
                if h in seen_hashes:
                    dest_folder = dest_root / "Duplicates"
                    dest = _unique_dest(dest_folder / f.name)
                    _move(f, dest, dry_run)
                    summary.records.append(MoveRecord(str(f), str(dest)))
                    summary.duplicates += 1
                    continue
                seen_hashes[h] = f

            cat = categorize(f.suffix, categories)
            dest_folder = dest_root / cat
            if by_date:
                mtime = datetime.fromtimestamp(f.stat().st_mtime)
                dest_folder = dest_folder / f"{mtime.year}" / f"{mtime.month:02d}"
            dest = _unique_dest(dest_folder / f.name)
            _move(f, dest, dry_run)
            summary.records.append(MoveRecord(str(f), str(dest)))
            summary.moved[cat] = summary.moved.get(cat, 0) + 1
        except (PermissionError, OSError) as e:
            summary.skipped.append(f"{f.name}: {e}")

    if not dry_run and log_path and summary.records:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(log_path, "w") as fp:
            json.dump(
                {
                    "timestamp": time.time(),
                    "root": str(root),
                    "records": [r.__dict__ for r in summary.records],
                },
                fp,
                indent=2,
            )
        summary.log_path = log_path

    return summary


def undo(log_path: Path, dry_run: bool = False) -> int:
    """Reverse a previous run using its manifest. Moves files back to
    their original locations, most-recent-move-first, and cleans up
    any category folders left empty afterward."""
    data = json.loads(Path(log_path).read_text())
    records = data["records"]
    touched_dirs: set[Path] = set()
    count = 0

    for rec in reversed(records):
        moved_to, original = Path(rec["dst"]), Path(rec["src"])
        if moved_to.exists():
            if not dry_run:
                original.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(moved_to), str(original))
            touched_dirs.add(moved_to.parent)
            count += 1

    if not dry_run:
        for d in touched_dirs:
            _cleanup_empty(d)

    return count


def _cleanup_empty(folder: Path) -> None:
    """Remove `folder` and any now-empty parents, up to (not including)
    the original root, so undo doesn't leave a trail of empty category
    folders behind."""
    current = folder
    for _ in range(6):  # sane depth limit, e.g. Category/Year/Month
        if not current.exists():
            return
        try:
            if any(current.iterdir()):
                return
            current.rmdir()
            current = current.parent
        except OSError:
            return
