"""Default category mapping and config-file loading."""
from __future__ import annotations

import json
from pathlib import Path

DEFAULT_CATEGORIES: dict[str, list[str]] = {
    "Documents":     [".doc", ".docx", ".odt", ".rtf", ".pages"],
    "PDFs":          [".pdf"],
    "Spreadsheets":  [".xls", ".xlsx", ".ods", ".csv", ".numbers"],
    "Presentations": [".ppt", ".pptx", ".odp", ".key"],
    "Images":        [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".heic", ".tif", ".tiff"],
    "Videos":        [".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv", ".webm"],
    "Audio":         [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"],
    "Archives":      [".zip", ".rar", ".7z", ".tar", ".gz", ".iso"],
    "Code":          [".py", ".js", ".ts", ".html", ".css", ".json", ".java", ".c", ".cpp",
                       ".cs", ".ps1", ".sh", ".rb", ".go", ".rs", ".php", ".ipynb"],
    "Executables":   [".exe", ".msi", ".bat", ".cmd", ".apk", ".app", ".dmg", ".deb", ".rpm", ".appimage"],
    "Text":          [".txt", ".md", ".log"],
    "Fonts":         [".ttf", ".otf", ".woff", ".woff2"],
}

# Folder names the organizer will never descend into or treat as loose
# files - both its own output folders and common project-tooling noise.
RESERVED_NAMES = {"Other", "Duplicates"}
DEFAULT_IGNORE_DIR_NAMES = {".git", ".svn", ".hg", "node_modules", "__pycache__",
                             ".venv", "venv", ".idea", ".vscode"}


def load_categories(config_path: Path | None) -> dict[str, list[str]]:
    """Merge a user-supplied JSON category file on top of the defaults.

    The JSON file should look like:
        {"Screenshots": [".png", ".jpg"], "Books": [".epub", ".mobi"]}
    Any category name that matches a default one overrides it entirely;
    new names are added alongside the defaults. If an extension you
    assign to a new/overridden category is still claimed by another
    default category, it's removed from that other category so there's
    no silent ambiguity about which folder a file ends up in.
    """
    merged = {k: list(v) for k, v in DEFAULT_CATEGORIES.items()}
    if not config_path:
        return merged
    data = json.loads(Path(config_path).read_text())
    for name, exts in data.items():
        normalized = [e.lower() if e.startswith(".") else f".{e.lower()}" for e in exts]
        for other_name, other_exts in merged.items():
            if other_name == name:
                continue
            merged[other_name] = [e for e in other_exts if e not in normalized]
        merged[name] = normalized
    return merged
