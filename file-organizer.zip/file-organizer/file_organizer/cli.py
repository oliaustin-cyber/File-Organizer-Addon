"""Command-line entry point. One command, one terminal, every platform."""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from . import __version__
from .config import load_categories
from .organizer import organize, undo as undo_run

try:
    from .icons import tag_category_folders
    _ICONS_AVAILABLE = True
except Exception:  # pragma: no cover - icons module has no hard deps, but be safe
    _ICONS_AVAILABLE = False


def _default_log_dir() -> Path:
    return Path.home() / ".file-organizer" / "logs"


def _most_recent_log() -> Path | None:
    log_dir = _default_log_dir()
    if not log_dir.exists():
        return None
    logs = sorted(log_dir.glob("run-*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    return logs[0] if logs else None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="file-organizer",
        description="Organize a messy folder by file type - recursive, dedupe, "
                     "date-sorting, dry-run preview, and full undo. Works the "
                     "same way on Windows, macOS, and Linux.",
    )
    parser.add_argument("--version", action="version", version=f"file-organizer {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_org = sub.add_parser("organize", help="Organize a folder")
    p_org.add_argument("path", type=Path, help="Folder to organize")
    p_org.add_argument("-r", "--recursive", action="store_true",
                        help="Also organize files inside every subfolder, in place "
                             "(each subfolder gets its own category folders; nested "
                             "structure is preserved)")
    p_org.add_argument("--flatten", action="store_true",
                        help="Pull files from ALL subfolders up into category folders "
                             "at the top level instead (overrides --recursive)")
    p_org.add_argument("-n", "--dry-run", action="store_true",
                        help="Show what would happen without moving anything")
    p_org.add_argument("--dedupe", action="store_true",
                        help="Detect duplicate files by content (not just name) and "
                             "move extras into a Duplicates folder")
    p_org.add_argument("--by-date", action="store_true",
                        help="Further sort each category into Year/Month subfolders "
                             "based on the file's modified date")
    p_org.add_argument("-c", "--config", type=Path, default=None,
                        help="Path to a JSON file of custom categories, merged over the defaults")
    p_org.add_argument("--ignore", action="append", default=[], metavar="PATTERN",
                        help="Glob pattern to skip, repeatable (e.g. --ignore '*.tmp')")
    p_org.add_argument("--icons", action="store_true",
                        help="Best-effort: tag category folders with colored icons "
                             "(Windows: full support. macOS: needs 'fileicon' installed. "
                             "Linux: needs a gio-compatible file manager, e.g. GNOME Files)")
    p_org.add_argument("-v", "--verbose", action="store_true", help="List every file moved")
    p_org.set_defaults(func=_cmd_organize)

    p_undo = sub.add_parser("undo", help="Undo the most recent organize run")
    p_undo.add_argument("--log", type=Path, default=None,
                         help="Path to a specific run log (defaults to the most recent)")
    p_undo.add_argument("-n", "--dry-run", action="store_true",
                         help="Show what would be restored without moving anything")
    p_undo.set_defaults(func=_cmd_undo)

    return parser


def _cmd_organize(args: argparse.Namespace) -> int:
    path: Path = args.path
    if not path.exists() or not path.is_dir():
        print(f"Error: '{path}' is not a folder that exists.", file=sys.stderr)
        return 1

    categories = load_categories(args.config)
    log_dir = _default_log_dir()
    log_path = log_dir / f"run-{int(time.time())}.json"

    summary = organize(
        root=path.resolve(),
        categories=categories,
        recursive=args.recursive,
        flatten=args.flatten,
        dry_run=args.dry_run,
        dedupe=args.dedupe,
        by_date=args.by_date,
        ignore_patterns=args.ignore,
        log_path=log_path,
    )

    _print_summary(summary, args.dry_run, args.verbose)

    if args.icons and not args.dry_run:
        if _ICONS_AVAILABLE:
            tagged = tag_category_folders(path.resolve(), set(summary.moved) | ({"Duplicates"} if summary.duplicates else set()))
            if tagged:
                print(f"\nTagged {tagged} folder(s) with custom icons.")
            else:
                print("\nCouldn't tag folder icons on this system (see --help for requirements).")
        else:
            print("\nIcon tagging isn't available in this install.")

    return 0


def _cmd_undo(args: argparse.Namespace) -> int:
    log_path = args.log or _most_recent_log()
    if not log_path or not Path(log_path).exists():
        print("No run log found to undo. (Logs live in ~/.file-organizer/logs)", file=sys.stderr)
        return 1
    count = undo_run(Path(log_path), dry_run=args.dry_run)
    verb = "Would restore" if args.dry_run else "Restored"
    print(f"{verb} {count} file(s) to their original location.")
    return 0


def _print_summary(summary, dry_run: bool, verbose: bool) -> None:
    verb = "Would organize" if dry_run else "Organized"
    if not summary.moved and summary.duplicates == 0:
        print("Nothing to organize - already tidy.")
        return

    print(f"{verb}:")
    for cat, count in sorted(summary.moved.items()):
        print(f"  {cat}: {count} file(s)")
    if summary.duplicates:
        print(f"  Duplicates: {summary.duplicates} file(s)")

    if verbose:
        print("\nDetails:")
        for rec in summary.records:
            print(f"  {rec.src}\n    -> {rec.dst}")

    if summary.skipped:
        print(f"\n{len(summary.skipped)} file(s) skipped (in use or permission denied):")
        for s in summary.skipped[:5]:
            print(f"  {s}")
        if len(summary.skipped) > 5:
            print(f"  ...and {len(summary.skipped) - 5} more")

    if not dry_run and summary.log_path:
        print("\nUndo anytime with: file-organizer undo")


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
