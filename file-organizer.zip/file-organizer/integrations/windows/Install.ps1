<#
    Install.ps1  -  File Organizer Add-on installer

    - Copies scripts + icons to %LOCALAPPDATA%\FileOrganizerAddon
    - Adds "Organize This Folder" to the right-click menu for folders
      and empty space inside folders (current user only, no admin needed)
    - Replaces the default icon for common file types with a colorful
      flat icon set (backs up the original values first so Uninstall.ps1
      can fully restore them)

    Easiest way to run this: double-click Install.bat in the same folder.
    (That launcher avoids PowerShell's execution-policy prompt and keeps
    the window open so you can actually read what happened.)
#>

$ErrorActionPreference = "Stop"
$LogFile = Join-Path $env:TEMP "FileOrganizerAddon_install.log"
Start-Transcript -Path $LogFile -Force | Out-Null

function Finish($ok) {
    Stop-Transcript | Out-Null
    if (-not $ok) {
        Write-Host ""
        Write-Host "Log saved to: $LogFile" -ForegroundColor Yellow
    }
    Write-Host ""
    Read-Host "Press Enter to close this window"
}

try {
    $Source = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($Source)) {
        # $PSScriptRoot is unreliable inside a ps2exe-compiled .exe - fall
        # back to the running process's own file location instead.
        try {
            $Source = Split-Path -Parent ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName)
        } catch {
            $Source = Split-Path -Parent $MyInvocation.MyCommand.Path
        }
    }
    $InstallDir = Join-Path $env:LOCALAPPDATA "FileOrganizerAddon"

    Write-Host "Installing File Organizer Add-on to $InstallDir ..." -ForegroundColor Cyan

    # Files downloaded as part of a zip get tagged "blocked" by Windows
    # (Mark of the Web). Unblock everything first so PowerShell will run it.
    Get-ChildItem -Path $Source -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    Copy-Item -Path (Join-Path $Source "icons") -Destination $InstallDir -Recurse -Force
    Copy-Item -Path (Join-Path $Source "scripts") -Destination $InstallDir -Recurse -Force

    $OrganizeScript = Join-Path $InstallDir "scripts\Organize.ps1"
    $IconDir        = Join-Path $InstallDir "icons"

    if (-not (Test-Path $OrganizeScript)) { throw "Organize.ps1 failed to copy to $OrganizeScript" }
    if (-not (Test-Path $IconDir))        { throw "Icon folder failed to copy to $IconDir" }

    # ---------- Right-click context menu ----------
    $dirKey = "HKCU:\Software\Classes\Directory\shell\FileOrganizer"
    New-Item -Path $dirKey -Force | Out-Null
    Set-ItemProperty -Path $dirKey -Name "(default)" -Value "Organize This Folder"
    Set-ItemProperty -Path $dirKey -Name "Icon" -Value (Join-Path $IconDir "folder_root.ico")
    New-Item -Path "$dirKey\command" -Force | Out-Null
    Set-ItemProperty -Path "$dirKey\command" -Name "(default)" `
        -Value "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$OrganizeScript`" -Path `"%1`""

    $bgKey = "HKCU:\Software\Classes\Directory\Background\shell\FileOrganizer"
    New-Item -Path $bgKey -Force | Out-Null
    Set-ItemProperty -Path $bgKey -Name "(default)" -Value "Organize This Folder"
    Set-ItemProperty -Path $bgKey -Name "Icon" -Value (Join-Path $IconDir "folder_root.ico")
    New-Item -Path "$bgKey\command" -Force | Out-Null
    Set-ItemProperty -Path "$bgKey\command" -Name "(default)" `
        -Value "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$OrganizeScript`" -Path `"%V`""

    $dirKey2 = "HKCU:\Software\Classes\Directory\shell\FileOrganizerDeep"
    New-Item -Path $dirKey2 -Force | Out-Null
    Set-ItemProperty -Path $dirKey2 -Name "(default)" -Value "Organize This Folder (incl. subfolders)"
    Set-ItemProperty -Path $dirKey2 -Name "Icon" -Value (Join-Path $IconDir "folder_root.ico")
    New-Item -Path "$dirKey2\command" -Force | Out-Null
    Set-ItemProperty -Path "$dirKey2\command" -Name "(default)" `
        -Value "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$OrganizeScript`" -Path `"%1`" -IncludeSubfolders"

    Write-Host "Right-click menu installed." -ForegroundColor Green

    # ---------- Per-extension default icons ----------
    $ExtensionIcons = @{
        ".pdf"  = "pdf.ico";          ".doc"  = "documents.ico"; ".docx" = "documents.ico"
        ".odt"  = "documents.ico";    ".rtf"  = "documents.ico"
        ".xls"  = "spreadsheets.ico"; ".xlsx" = "spreadsheets.ico"; ".csv" = "spreadsheets.ico"
        ".ppt"  = "presentations.ico";".pptx" = "presentations.ico"
        ".zip"  = "archives.ico";     ".rar"  = "archives.ico"; ".7z" = "archives.ico"
        ".mp3"  = "audio.ico";        ".wav"  = "audio.ico";  ".flac" = "audio.ico"
        ".mp4"  = "videos.ico";       ".mov"  = "videos.ico";  ".mkv" = "videos.ico"
        ".txt"  = "text.ico";         ".md"   = "text.ico"
        ".ttf"  = "fonts.ico";        ".otf"  = "fonts.ico"
    }

    $BackupFile = Join-Path $InstallDir "icon_backup.json"
    $Backup = @{}
    $failedExtensions = @()

    foreach ($ext in $ExtensionIcons.Keys) {
        try {
            $classKey = "HKCU:\Software\Classes\$ext"
            $progId = $null
            if (Test-Path $classKey) {
                $progId = (Get-ItemProperty -Path $classKey -ErrorAction SilentlyContinue)."(default)"
            }
            if ([string]::IsNullOrWhiteSpace($progId)) {
                $progId = "FileOrganizerAddon$($ext.TrimStart('.'))"
                New-Item -Path $classKey -Force | Out-Null
                Set-ItemProperty -Path $classKey -Name "(default)" -Value $progId
            }
            $progKey = "HKCU:\Software\Classes\$progId"
            $iconKey = "$progKey\DefaultIcon"
            New-Item -Path $progKey -Force | Out-Null

            $existingIcon = $null
            if (Test-Path $iconKey) {
                $existingIcon = (Get-ItemProperty -Path $iconKey -ErrorAction SilentlyContinue)."(default)"
            }
            $Backup[$ext] = @{ ProgId = $progId; PreviousIcon = $existingIcon }

            New-Item -Path $iconKey -Force | Out-Null
            $iconPath = Join-Path $IconDir $ExtensionIcons[$ext]
            Set-ItemProperty -Path $iconKey -Name "(default)" -Value "$iconPath,0"
        } catch {
            $failedExtensions += $ext
            Write-Host "  Skipped $ext (couldn't set icon: $($_.Exception.Message))" -ForegroundColor Yellow
        }
    }

    $Backup | ConvertTo-Json -Depth 5 | Out-File -FilePath $BackupFile -Encoding utf8 -Force
    Write-Host "Custom file-type icons applied ($($ExtensionIcons.Count - $failedExtensions.Count)/$($ExtensionIcons.Count) extensions)." -ForegroundColor Green

    try {
        Add-Type -Namespace Shell32 -Name Refresh -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("shell32.dll")]
public static extern void SHChangeNotify(int wEventId, int uFlags, IntPtr dwItem1, IntPtr dwItem2);
"@
        [Shell32.Refresh]::SHChangeNotify(0x8000000, 0x1000, [IntPtr]::Zero, [IntPtr]::Zero)
    } catch {
        Write-Host "Shell refresh skipped (not critical)." -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host "INSTALL COMPLETE" -ForegroundColor Cyan
    Write-Host "Right-click any folder and choose 'Organize This Folder'." -ForegroundColor Cyan
    Write-Host "If icons don't refresh immediately, sign out and back in (or restart explorer.exe)." -ForegroundColor Yellow
    Write-Host "To remove everything later, double-click Uninstall.bat." -ForegroundColor Yellow

    Finish $true
}
catch {
    Write-Host ""
    Write-Host "INSTALL FAILED" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    Finish $false
    exit 1
}
