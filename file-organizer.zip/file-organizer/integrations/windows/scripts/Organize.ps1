<#
    Organize.ps1
    Sorts the files in a target folder into category subfolders
    (Documents, Images, Videos, Audio, Archives, Code, Spreadsheets,
    Presentations, Executables, Text, Fonts, Other), then tags each
    subfolder with a colored icon via desktop.ini so it's easy to
    scan a window at a glance.

    Usage (called automatically by the right-click menu):
        powershell -ExecutionPolicy Bypass -File Organize.ps1 -Path "C:\Some\Folder" [-IncludeSubfolders]
#>

param(
    [Parameter(Mandatory = $true)][string]$Path,
    [switch]$IncludeSubfolders
)

Add-Type -AssemblyName System.Windows.Forms

try {
    $ErrorActionPreference = "Stop"
    $AddonRoot = Split-Path -Parent $PSScriptRoot
    $IconDir   = Join-Path $AddonRoot "icons"

    $Categories = [ordered]@{
        "Documents"     = @(".doc",".docx",".odt",".rtf",".pages")
        "PDFs"          = @(".pdf")
        "Spreadsheets"  = @(".xls",".xlsx",".ods",".csv",".numbers")
        "Presentations" = @(".ppt",".pptx",".odp",".key")
        "Images"        = @(".jpg",".jpeg",".png",".gif",".bmp",".svg",".webp",".heic",".tif",".tiff")
        "Videos"        = @(".mp4",".mov",".avi",".mkv",".wmv",".flv",".webm")
        "Audio"         = @(".mp3",".wav",".flac",".aac",".ogg",".m4a")
        "Archives"      = @(".zip",".rar",".7z",".tar",".gz",".iso")
        "Code"          = @(".py",".js",".ts",".html",".css",".json",".java",".c",".cpp",".cs",".ps1",".sh",".rb",".go",".rs",".php")
        "Executables"   = @(".exe",".msi",".bat",".cmd",".apk")
        "Text"          = @(".txt",".md",".log")
        "Fonts"         = @(".ttf",".otf",".woff",".woff2")
    }

    $FolderIconMap = @{
        "Documents"     = "folder_documents.ico"; "PDFs"          = "folder_pdf.ico"
        "Spreadsheets"  = "folder_spreadsheets.ico"; "Presentations" = "folder_presentations.ico"
        "Images"        = "folder_images.ico";    "Videos"        = "folder_videos.ico"
        "Audio"         = "folder_audio.ico";     "Archives"      = "folder_archives.ico"
        "Code"          = "folder_code.ico";      "Executables"   = "folder_executables.ico"
        "Text"          = "folder_text.ico";      "Fonts"         = "folder_fonts.ico"
        "Other"         = "folder_other.ico"
    }

    function Get-Category([string]$extension) {
        foreach ($cat in $Categories.Keys) {
            if ($Categories[$cat] -contains $extension.ToLower()) { return $cat }
        }
        return "Other"
    }

    function Set-FolderIcon([string]$folderPath, [string]$iconFile) {
        try {
            $iconSource = Join-Path $IconDir $iconFile
            if (-not (Test-Path $iconSource)) { return }
            $localIcon = Join-Path $folderPath ".folder_icon.ico"
            Copy-Item -Path $iconSource -Destination $localIcon -Force
            $ini = Join-Path $folderPath "desktop.ini"
            @"
[.ShellClassInfo]
IconResource=$localIcon,0
[ViewState]
Mode=
Vid=
FolderType=Generic
"@ | Out-File -FilePath $ini -Encoding ascii -Force

            attrib +h +s $ini | Out-Null
            attrib +h $localIcon | Out-Null
            attrib +s $folderPath | Out-Null
        } catch {
            # A folder icon failing to apply shouldn't stop the whole
            # organize job - the files still get sorted correctly.
        }
    }

    if (-not (Test-Path $Path)) {
        throw "Folder not found: $Path"
    }

    $skipPattern = '\\(Documents|PDFs|Spreadsheets|Presentations|Images|Videos|Audio|Archives|Code|Executables|Text|Fonts|Other)(\\|$)'
    $targetFiles = Get-ChildItem -Path $Path -File -Recurse:$IncludeSubfolders -ErrorAction SilentlyContinue |
        Where-Object { $_.DirectoryName -notmatch $skipPattern }

    $moved = @{}
    $errors = @()

    foreach ($file in $targetFiles) {
        try {
            $cat = Get-Category $file.Extension
            $destFolder = Join-Path $Path $cat
            if (-not (Test-Path $destFolder)) {
                New-Item -ItemType Directory -Path $destFolder -Force | Out-Null
                $icon = $FolderIconMap[$cat]
                if ($icon) { Set-FolderIcon -folderPath $destFolder -iconFile $icon }
            }
            $destPath = Join-Path $destFolder $file.Name
            if (Test-Path $destPath) {
                $base = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)
                $ext  = $file.Extension
                $i = 1
                while (Test-Path (Join-Path $destFolder "$base ($i)$ext")) { $i++ }
                $destPath = Join-Path $destFolder "$base ($i)$ext"
            }
            Move-Item -Path $file.FullName -Destination $destPath -Force
            $moved[$cat] = ($moved[$cat] + 1)
        } catch {
            # Common causes: file is open in another program, or read-only.
            # Skip it and keep going instead of aborting the whole batch.
            $errors += "$($file.Name): $($_.Exception.Message)"
        }
    }

    if ($moved.Count -eq 0 -and $errors.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "Nothing to organize - this folder is already tidy.",
            "File Organizer") | Out-Null
    } else {
        $summary = ($moved.GetEnumerator() | Sort-Object Name | ForEach-Object { "  $($_.Key): $($_.Value) file(s)" }) -join "`n"
        $msg = "Organized `"$Path`":`n`n$summary"
        if ($errors.Count -gt 0) {
            $msg += "`n`n$($errors.Count) file(s) skipped (in use or locked):`n" + (($errors | Select-Object -First 5) -join "`n")
        }
        [System.Windows.Forms.MessageBox]::Show($msg, "File Organizer - Done") | Out-Null
    }
}
catch {
    [System.Windows.Forms.MessageBox]::Show(
        "File Organizer ran into a problem:`n`n$($_.Exception.Message)",
        "File Organizer - Error",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
}
