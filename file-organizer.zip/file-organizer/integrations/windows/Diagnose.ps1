<#
    Diagnose.ps1 - checks whether the File Organizer Add-on is actually
    registered correctly, and prints a plain-English report.

    Checks: installed files, right-click menu registry, per-extension
    icon overrides, Windows 11's "Show more options" behavior, and
    Explorer status.
#>

Write-Host "=== File Organizer Add-on Diagnostic ===" -ForegroundColor Cyan
Write-Host ""

$InstallDir = Join-Path $env:LOCALAPPDATA "FileOrganizerAddon"
$OrganizeScript = Join-Path $InstallDir "scripts\Organize.ps1"
$IconDir = Join-Path $InstallDir "icons"

# 1. Installed files
Write-Host "[1] Installed files" -ForegroundColor Yellow
if (Test-Path $OrganizeScript) {
    Write-Host "    OK - Organize.ps1 found at $OrganizeScript" -ForegroundColor Green
} else {
    Write-Host "    MISSING - $OrganizeScript does not exist." -ForegroundColor Red
    Write-Host "    -> Run Install.bat first." -ForegroundColor Red
}
Write-Host ""

# 2. Registry keys for the right-click menu
Write-Host "[2] Right-click menu registry keys" -ForegroundColor Yellow
$keys = @(
    "HKCU:\Software\Classes\Directory\shell\FileOrganizer",
    "HKCU:\Software\Classes\Directory\shell\FileOrganizerDeep",
    "HKCU:\Software\Classes\Directory\Background\shell\FileOrganizer"
)
$allGood = $true
foreach ($k in $keys) {
    if (Test-Path $k) {
        $cmdKey = Join-Path $k "command"
        $cmdVal = (Get-ItemProperty -Path $cmdKey -ErrorAction SilentlyContinue)."(default)"
        Write-Host "    OK   - $k" -ForegroundColor Green
        if (-not $cmdVal) {
            Write-Host "           WARNING: no command value set under this key" -ForegroundColor Red
            $allGood = $false
        }
    } else {
        Write-Host "    MISSING - $k" -ForegroundColor Red
        $allGood = $false
    }
}
Write-Host ""

# 3. Per-extension icon overrides
Write-Host "[3] File-type icon overrides" -ForegroundColor Yellow
$ExtensionIcons = @{
    ".pdf"  = "pdf.ico";          ".doc"  = "documents.ico"; ".docx" = "documents.ico"
    ".odt"  = "documents.ico";    ".rtf"  = "documents.ico"
    ".xls"  = "spreadsheets.ico"; ".xlsx" = "spreadsheets.ico"; ".csv" = "spreadsheets.ico"
    ".ppt"  = "presentations.ico";".pptx" = "presentations.ico"
    ".zip"  = "archives.ico";     ".rar"  = "archives.ico"; ".7z" = "archives.ico"
    ".mp3"  = "audio.ico";        ".wav"  = "audio.ico";  ".flac" = "audio.ico"
    ".mp4"  = "videos.ico";       ".mov"  = "videos.ico";  ".mkv" = "videos.ico"
    ".txt"  = "text.ico";         ".md"   = "text.ico"
    ".ttf"  = "fonts.ico";        ".otf"  = "fonts.ico"
}
$iconOk = 0
$iconMissing = @()
$iconFileMissing = @()

foreach ($ext in $ExtensionIcons.Keys) {
    $classKey = "HKCU:\Software\Classes\$ext"
    $progId = if (Test-Path $classKey) { (Get-ItemProperty -Path $classKey -ErrorAction SilentlyContinue)."(default)" } else { $null }

    if ([string]::IsNullOrWhiteSpace($progId)) {
        $iconMissing += $ext
        continue
    }
    $iconKey = "HKCU:\Software\Classes\$progId\DefaultIcon"
    $iconVal = if (Test-Path $iconKey) { (Get-ItemProperty -Path $iconKey -ErrorAction SilentlyContinue)."(default)" } else { $null }

    if ([string]::IsNullOrWhiteSpace($iconVal)) {
        $iconMissing += $ext
        continue
    }
    $iconFilePath = ($iconVal -split ",")[0]
    if (-not (Test-Path $iconFilePath)) {
        $iconFileMissing += "$ext -> $iconFilePath"
        continue
    }
    $iconOk++
}

Write-Host "    $iconOk / $($ExtensionIcons.Count) extensions have a working icon override." -ForegroundColor $(if ($iconOk -eq $ExtensionIcons.Count) { "Green" } else { "Yellow" })
if ($iconMissing.Count -gt 0) {
    Write-Host "    No override registered for: $($iconMissing -join ', ')" -ForegroundColor Red
    Write-Host "    -> Re-run Install.bat." -ForegroundColor Red
}
if ($iconFileMissing.Count -gt 0) {
    Write-Host "    Override registered but the .ico file is missing on disk:" -ForegroundColor Red
    foreach ($m in $iconFileMissing) { Write-Host "      $m" -ForegroundColor Red }
    Write-Host "    -> Re-run Install.bat (it will re-copy the icons\ folder)." -ForegroundColor Red
}
if ($iconOk -eq $ExtensionIcons.Count) {
    Write-Host "    Registry is correct - if icons still look old in Explorer, that's" -ForegroundColor DarkGray
    Write-Host "    Windows' icon cache, not the add-on. See the fix offered below." -ForegroundColor DarkGray
}
Write-Host ""

# 4. Windows 11 streamlined context menu check
Write-Host "[4] Windows version / context menu style" -ForegroundColor Yellow
$build = [System.Environment]::OSVersion.Version.Build
$isWin11 = $build -ge 22000
$classicMenuKey = "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32"
$classicMenuActive = Test-Path $classicMenuKey

if ($isWin11) {
    Write-Host "    You're on Windows 11 (build $build)." -ForegroundColor DarkGray
    if ($classicMenuActive) {
        Write-Host "    Classic full context menu is already enabled." -ForegroundColor Green
    } else {
        Write-Host "    Custom right-click entries are under 'Show more options' by default" -ForegroundColor Yellow
        Write-Host "    on Windows 11 - not missing, just hidden a click deeper." -ForegroundColor Yellow
    }
} else {
    Write-Host "    Older Windows version - all right-click entries show directly." -ForegroundColor DarkGray
}
Write-Host ""

# 5. Explorer status
Write-Host "[5] Explorer status" -ForegroundColor Yellow
$explorerStart = (Get-Process explorer -ErrorAction SilentlyContinue | Select-Object -First 1).StartTime
if ($explorerStart) {
    Write-Host "    Explorer.exe has been running since: $explorerStart" -ForegroundColor DarkGray
}
Write-Host ""

# ---------- Summary / offer fixes ----------
Write-Host "=== Summary ===" -ForegroundColor Cyan
if (-not ((Test-Path $OrganizeScript) -and $allGood)) {
    Write-Host "Menu setup is incomplete - re-run Install.bat, then run this script again." -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to close this window"
    exit
}

$menuFixOffered = $false
if ($isWin11 -and -not $classicMenuActive) {
    Write-Host "Want this script to permanently restore the full classic right-click" -ForegroundColor Yellow
    Write-Host "menu (Windows 10 style)? Affects ALL right-click menus system-wide," -ForegroundColor Yellow
    Write-Host "fully reversible by running this script again and choosing to revert." -ForegroundColor Yellow
    $answer = Read-Host "Enable the classic full context menu now? (y/n)"
    if ($answer -eq "y") {
        New-Item -Path $classicMenuKey -Force | Out-Null
        Set-ItemProperty -Path $classicMenuKey -Name "(default)" -Value "" -Force
        $menuFixOffered = $true
    }
}

if ($iconOk -eq $ExtensionIcons.Count -and $iconMissing.Count -eq 0 -and $iconFileMissing.Count -eq 0) {
    Write-Host ""
    Write-Host "Icon registry is correct. If Explorer still shows old icons, Windows'" -ForegroundColor Yellow
    Write-Host "icon cache needs clearing - this script can do that too." -ForegroundColor Yellow
    $answer2 = Read-Host "Clear the icon cache and restart Explorer now? (y/n)"
    if ($answer2 -eq "y") {
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
        Start-Process "ie4uinit.exe" -ArgumentList "-ClearIconCache" -Wait -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
        Start-Process explorer.exe
        Write-Host "Done. Icons should refresh within a few seconds." -ForegroundColor Green
    }
} elseif ($menuFixOffered) {
    Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    Start-Process explorer.exe
    Write-Host "Explorer restarted with the classic menu enabled." -ForegroundColor Green
}

Write-Host ""
Read-Host "Press Enter to close this window"
