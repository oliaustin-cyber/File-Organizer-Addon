@echo off
title File Organizer - Diagnose
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Diagnose.ps1"
