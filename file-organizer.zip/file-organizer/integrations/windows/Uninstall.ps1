<#
    Uninstall.ps1  -  removes the File Organizer Add-on completely:
    - Deletes the right-click context menu entries
    - Restores original file-type icons (or removes the override if
      there wasn't one before)
    - Deletes the installed copy of the scripts/icons

    Note: this does NOT move any files back or delete the category
    folders (Documents, Images, etc.) that Organize.ps1 created -
    your files stay exactly where they were sorted to.

    Easiest way to run this: double-click Uninstall.bat in the same folder.
#>

$ErrorActionPreference = "Stop"

function Finish($ok) {
    Write-Host ""
    Read-Host "Press Enter to close this window"
}

try {
    $InstallDir = Join-Path $env:LOCALAPPDATA "FileOrganizerAddon"
    $BackupFile = Join-Path $InstallDir "icon_backup.json"

    Write-Host "Removing File Organizer Add-on ..." -ForegroundColor Cyan

    # ---------- Remove context menu entries ----------
    Remove-Item -Path "HKCU:\Software\Classes\Directory\shell\FileOrganizer" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path "HKCU:\Software\Classes\Directory\shell\FileOrganizerDeep" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path "HKCU:\Software\Classes\Directory\Background\shell\FileOrganizer" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Right-click menu entries removed." -ForegroundColor Green

    # ---------- Restore original icons ----------
    if (Test-Path $BackupFile) {
        $Backup = Get-Content $BackupFile -Raw | ConvertFrom-Json
        foreach ($ext in $Backup.PSObject.Properties.Name) {
            try {
                $entry = $Backup.$ext
                $progKey = "HKCU:\Software\Classes\$($entry.ProgId)"
                $iconKey = "$progKey\DefaultIcon"
                if ($entry.PreviousIcon) {
                    Set-ItemProperty -Path $iconKey -Name "(default)" -Value $entry.PreviousIcon -ErrorAction SilentlyContinue
                } else {
                    Remove-Item -Path $iconKey -Recurse -Force -ErrorAction SilentlyContinue
                }
                if ($entry.ProgId -like "FileOrganizerAddon*") {
                    Remove-Item -Path $progKey -Recurse -Force -ErrorAction SilentlyContinue
                }
            } catch {
                Write-Host "  Couldn't fully restore icon for $ext (non-fatal): $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }
        Write-Host "Original file-type icons restored." -ForegroundColor Green
    } else {
        Write-Host "No icon backup found - skipping icon restore." -ForegroundColor Yellow
    }

    # ---------- Refresh shell ----------
    try {
        Add-Type -Namespace Shell32 -Name Refresh -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("shell32.dll")]
public static extern void SHChangeNotify(int wEventId, int uFlags, IntPtr dwItem1, IntPtr dwItem2);
"@
        [Shell32.Refresh]::SHChangeNotify(0x8000000, 0x1000, [IntPtr]::Zero, [IntPtr]::Zero)
    } catch {}

    # ---------- Delete installed files ----------
    if (Test-Path $InstallDir) {
        Remove-Item -Path $InstallDir -Recurse -Force
    }

    Write-Host ""
    Write-Host "UNINSTALL COMPLETE" -ForegroundColor Cyan
    Write-Host "Sign out and back in if any icons look stale." -ForegroundColor Yellow
    Finish $true
}
catch {
    Write-Host ""
    Write-Host "UNINSTALL HIT AN ERROR" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Finish $false
    exit 1
}
