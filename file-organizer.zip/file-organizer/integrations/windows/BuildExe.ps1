<#
    BuildExe.ps1  -  turns Install.ps1 / Uninstall.ps1 / Diagnose.ps1 into
    real, standalone, double-clickable .exe files.

    Why this has to run on YOUR machine: producing a genuine Windows .exe
    requires Windows + Microsoft's own PowerShell engine, neither of which
    exist wherever this add-on was generated. This script uses "ps2exe" -
    a small, widely used, open-source wrapper tool distributed through
    Microsoft's own PowerShell Gallery - to do the actual compiling,
    right here on your PC. You only need to run this once.

    Run it via BuildExe.bat, or directly:
        powershell -ExecutionPolicy Bypass -File BuildExe.ps1
#>

$ErrorActionPreference = "Stop"

function Finish($ok) {
    Write-Host ""
    Read-Host "Press Enter to close this window"
}

try {
    $Source = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($Source)) { $Source = Split-Path -Parent $MyInvocation.MyCommand.Path }
    $IconPath = Join-Path $Source "icons\folder_root.ico"

    Write-Host "=== Building real .exe files ===" -ForegroundColor Cyan
    Write-Host ""

    if (-not (Get-Module -ListAvailable -Name ps2exe)) {
        Write-Host "ps2exe isn't installed yet - installing it from the PowerShell" -ForegroundColor Yellow
        Write-Host "Gallery (Microsoft's official module repository)..." -ForegroundColor Yellow
        Write-Host "This step needs an internet connection, one time only." -ForegroundColor Yellow
        Write-Host ""
        try {
            Install-Module -Name ps2exe -Scope CurrentUser -Force -AllowClobber
        } catch {
            throw "Couldn't install ps2exe automatically. Open PowerShell yourself and run:`n    Install-Module -Name ps2exe -Scope CurrentUser -Force`nthen re-run this script.`n`nOriginal error: $($_.Exception.Message)"
        }
    }
    Import-Module ps2exe -Force
    Write-Host "ps2exe ready." -ForegroundColor Green
    Write-Host ""

    $targets = @(
        @{ Name = "Install";   Title = "File Organizer - Install" },
        @{ Name = "Uninstall"; Title = "File Organizer - Uninstall" },
        @{ Name = "Diagnose";  Title = "File Organizer - Diagnose" }
    )

    foreach ($t in $targets) {
        $inPath  = Join-Path $Source "$($t.Name).ps1"
        $outPath = Join-Path $Source "$($t.Name).exe"
        if (-not (Test-Path $inPath)) {
            Write-Host "Skipping $($t.Name) - $inPath not found." -ForegroundColor Yellow
            continue
        }
        Write-Host "Building $($t.Name).exe ..." -ForegroundColor Cyan
        Invoke-ps2exe -inputFile $inPath -outputFile $outPath `
            -iconFile $IconPath -title $t.Title -company "FileOrganizerAddon" `
            -noConsole:$false -requireAdmin:$false
        if (Test-Path $outPath) {
            Write-Host "  -> $outPath" -ForegroundColor Green
        } else {
            Write-Host "  -> FAILED to produce $outPath" -ForegroundColor Red
        }
        Write-Host ""
    }

    Write-Host "=== Done ===" -ForegroundColor Cyan
    Write-Host "You can now double-click Install.exe, Uninstall.exe, and Diagnose.exe" -ForegroundColor Green
    Write-Host "directly - the .bat files are no longer needed (but harmless to keep)." -ForegroundColor Green
    Write-Host "The .ps1 files should stay in this folder - the .exe files still need" -ForegroundColor Yellow
    Write-Host "the icons\ folder next to them at install time." -ForegroundColor Yellow

    Finish $true
}
catch {
    Write-Host ""
    Write-Host "BUILD FAILED" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Finish $false
    exit 1
}
