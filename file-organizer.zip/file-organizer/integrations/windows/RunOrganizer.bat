@echo off
title File Organizer - Run Directly
setlocal

if "%~1"=="" (
    echo No folder was dropped onto this file.
    echo.
    set /p FOLDER="Paste the full path of the folder to organize, then press Enter: "
) else (
    set "FOLDER=%~1"
)

if not exist "%FOLDER%" (
    echo.
    echo That path doesn't exist: %FOLDER%
    echo.
    pause
    exit /b 1
)

set "SCRIPT=%LOCALAPPDATA%\FileOrganizerAddon\scripts\Organize.ps1"
if not exist "%SCRIPT%" (
    echo.
    echo The add-on isn't installed yet ^(or install failed^).
    echo Expected to find: %SCRIPT%
    echo Run Install.bat first.
    echo.
    pause
    exit /b 1
)

echo.
echo Organizing: %FOLDER%
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Path "%FOLDER%"

echo.
echo Done. Check the folder, or the popup that appeared.
pause
