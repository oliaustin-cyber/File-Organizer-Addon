@echo off
title File Organizer - Build EXE Files
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BuildExe.ps1"
