#!/bin/bash
# Nautilus (GNOME Files) script: right-click a folder -> Scripts -> Organize Here
# Install: copy this file into ~/.local/share/nautilus/scripts/, make it
# executable (chmod +x), then restart Nautilus (nautilus -q).
# Requires: file-organizer installed (pip install file-organizer-cli)

if [ -n "$NAUTILUS_SCRIPT_SELECTED_FILE_PATHS" ]; then
    TARGET=$(echo "$NAUTILUS_SCRIPT_SELECTED_FILE_PATHS" | head -n 1)
else
    TARGET="$PWD"
fi

file-organizer organize "$TARGET" --recursive
notify-send "File Organizer" "Finished organizing $TARGET" 2>/dev/null || true
