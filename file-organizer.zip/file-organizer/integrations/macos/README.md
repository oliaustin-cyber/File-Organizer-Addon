# macOS Quick Action (Finder right-click)

Turn `file-organizer` into a right-click option in Finder using Automator
(built into every Mac, no extra installs beyond the CLI itself):

1. Install the CLI first: `pip3 install file-organizer-cli`
2. Open **Automator** -> File -> New -> **Quick Action**.
3. Set "Workflow receives current" to **folders** in **Finder**.
4. Add a **Run Shell Script** action, set Shell to `/bin/bash`,
   "Pass input" to **as arguments**, and paste:
   ```bash
   for f in "$@"; do
       /usr/local/bin/file-organizer organize "$f" --recursive
   done
   ```
   (If `which file-organizer` shows a different path, use that instead
   of `/usr/local/bin/file-organizer` - Quick Actions don't load your
   shell's PATH.)
5. Save it as **"Organize Folder"**.
6. Right-click any folder in Finder -> Quick Actions -> Organize Folder.

## Custom folder icons (optional)
Install the community [`fileicon`](https://github.com/mklement0/fileicon)
tool (`brew install fileicon`) and pass `--icons` to any `organize`
command - file-organizer will use it automatically if present.
